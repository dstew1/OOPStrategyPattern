/*
Student Name: Daniel Stewart    
Student Number: 041029499
Course & Section #: 23S_CST8288_021
Declaration:
This is my own original work and is free from Plagiarism.
*/
package folder;

/**
 * This is the interface which provide the convert() method for this program
 * @author Daniel Stewart
 * @version 20.0.1
 * 
 */
public interface UnitTypeConverter {
    double convert(double value);
}
